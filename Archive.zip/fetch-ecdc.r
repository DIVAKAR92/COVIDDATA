library(lubridate)
library(utils)
library(httr)
library(dplyr)

# date_offset <- 0
url <- "https://opendata.ecdc.europa.eu/covid19/casedistribution/csv/"
# date_iso <- as.character(Sys.Date() - date_offset)
# url <- sprintf(url_string, date_iso)

url_page <- "https://www.ecdc.europa.eu/en/publications-data/download-todays-data-geographic-distribution-covid-19-cases-worldwide"
tryCatch({
  #download the dataset from the ECDC website to a local temporary file
  r <- RETRY("GET", "https://opendata.ecdc.europa.eu/covid19/casedistribution/csv/", 
             write_disk("data/COVID-19-up-to-date.csv", overwrite=TRUE))
  
  if (http_error(r)) {
    stop("Error downloading file")
  }
},
error = function(e) {
  stop(sprintf("Error downloading file '%s': %s, please check %s",
               url, e$message, url_page))
})

d <- read.csv("data/COVID-19-up-to-date.csv", stringsAsFactors = FALSE)



d$dateRep = as.Date(d$dateRep, format = "%d/%m/%Y")
d$t <- lubridate::decimal_date(as.Date(d$dateRep, format = "%d/%m/%Y"))
d <- d[order(d$'countriesAndTerritories', d$t, decreasing = FALSE), ]
names(d)[names(d) == "countriesAndTerritories"] <- "Country"
# Read which countires to use
countries <- readRDS('data/regions.rds')
d = d %>% filter(Country %in% countries$Regions)
names(d)[names(d) == "deaths"] <- "Deaths"
names(d)[names(d) == "cases"] <- "Cases"
names(d)[names(d) == "dateRep"] <- "DateRep"
# d$Cases = abs(d$Cases)
# d$Deaths = abs(d$Deaths)

## Correct for negative deaths and cases 
id = which(d$Cases < 0)
d$Cases[id[1:2]] = abs(d$Cases[id[1:2]])
d$Cases[id[3]] = round(mean(d$Cases[c((id[3]-1),(id[3]+1))]), 0)
d$Cases[id[4]] = round(mean(d$Cases[c((id[4]-1),(id[4]+1))]), 0)
d$Cases[id[5]] = round(mean(d$Cases[c((id[5]-1),(id[5]+1))]), 0)

id = which(d$Deaths < 0)
d$Deaths[id[1]] = abs(d$Deaths[id[1]])
d$Deaths[id[2]] = round(mean(d$Deaths[c((id[2]-1),(id[2]+1))]), 0)
d$Deaths[id[3]] = abs(d$Deaths[id[3]])
#d$Deaths[id[4]] = abs(d$Deaths[id[4]])
#d$Deaths[id[5]] = round(mean(d$Deaths[c((id[5]-1),(id[5]+1))]), 0)

#============================== read the data UK =====================================
library(lubridate)  

mon_day = today(tzone = "GMT")
mon = as.character(lubridate::month(mon_day,label=TRUE,abbr=TRUE))
day_today = day(mon_day)

file_ext = paste0("data_2020-",mon, "-",day_today, ".csv")
file_name = paste0("/Users/divakarkumar/Downloads/", file_ext)
file_1 = read.csv(file_name)  

ids = grepl("Cases", names(file_1), fixed = TRUE) + 
  grepl("Deaths", names(file_1), fixed = TRUE) +
  grepl("date", names(file_1), fixed = TRUE) 
cols_to_select = names(file_1)[as.logical(ids)]
file_1 = file_1[, cols_to_select]

file_ext2 = paste0("data_2020-",mon, "-",day_today, "-2.csv")
file_name2 = paste0("/Users/divakarkumar/Downloads/", file_ext2)
file_2 = read.csv(file_name2)  

ids = grepl("Cases", names(file_2), fixed = TRUE) + 
  grepl("Deaths", names(file_2), fixed = TRUE) +
  grepl("date", names(file_2), fixed = TRUE) 
cols_to_select = names(file_2)[as.logical(ids)]
file_2 = file_2[, cols_to_select]

data = dplyr::full_join(file_1, file_2)
data = data %>% dplyr::rename(Cases = newCasesBySpecimenDate, 
                              Deaths = newDeaths28DaysByDeathDate,
                              DateRep = date)
data = data[, c("DateRep", "Cases", "Deaths")]
data$DateRep = as.Date(data$DateRep, "%Y-%m-%d")
data$DateRep = data$DateRep + days(1)

#=======================================================================================
duk = d %>% filter(geoId == "UK")
d_new = dplyr::left_join(duk[, c("DateRep", "Cases", "Deaths")], data, by = "DateRep")
d_new[is.na(d_new)] = 0

d$Cases[which(d$geoId == "UK")] = d_new$Cases.y
d$Deaths[which(d$geoId == "UK")] = d_new$Deaths.y

#=======================================================================================

saveRDS(d, "data/COVID-19-up-to-date.rds")
write.csv(d, file = "data/COVID-19-up-to-date.csv", row.names = F)

