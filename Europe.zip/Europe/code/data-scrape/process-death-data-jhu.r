#AUTHOR: Ben Jeffrey and OJ Watson
#Copied from https://github.com/ncov-ic/ncov-outputs/blob/usa_incoming_nyt_jh/src/usa_incoming_nyt_jhu/script.R

library(tidyverse)
library(janitor)
library(RCurl)
library(cdlTools)
library(lubridate)
library(dplyr)


countries <- c("Denmark", "Italy", "Germany","Spain",
  "United_Kingdom", "France", "Norway", "Belgium", "Austria","Sweden",
  "Switzerland", "Greece", "Portugal","Netherlands")
code <- c("DK", "IT", "DE", "ES", "GB", "FR", "NO", "BE",
          "AT", "SE", "CH", "GR", "PT", "NL")
df = data.frame(countriesAndTerritories = countries, code = code)

data = read.csv("Europe/data/COVID-19-up-to-date.csv")
data = data %>% filter(countriesAndTerritories %in% countries)

names(data)[which(names(data) == "dateRep")]  = "date"
names(data)[which(names(data) == "cases")]  = "daily_cases"
names(data)[which(names(data) == "deaths")]  = "daily_deaths"

data = dplyr::left_join(data, df, by = "countriesAndTerritories")
data$date = as.Date(as.character(data$date), format = "%d/%m/%Y")

data = data %>% arrange(date) %>%
  group_by(code) %>% mutate(cumulative_cases = cumsum(daily_cases),
                            cumulative_deaths = cumsum(daily_deaths))

date_min <- ymd("2020-01-01")

data = data %>% filter(date >= date_min)

cols_to_keep = c("code","date","cumulative_cases","cumulative_deaths",
                 "daily_cases","daily_deaths")

all_data = data[ , cols_to_keep]

saveRDS(all_data, "Europe/data/europe_death_data_padded.rds")


