library(tidyr)
library(lubridate)
library(stringr)
library(dplyr)
library(data.table)


# data_pop = read.csv("Europe/data/popt_ifr.csv")
# data_pop$X = NULL
# names(data_pop)[which(names(data_pop) == "country")]  = "state"
# data_pop <- data_pop %>% mutate(state = recode(state,
#                               "United Kingdom" = "United_Kingdom"))
# 
# Region <- c("Denmark", "Italy", "Germany","Spain",
#                "United_Kingdom", "France", "Norway", "Belgium", "Austria","Sweden",
#                "Switzerland", "Greece", "Portugal","Netherlands")
# code <- c("DK", "IT", "DE", "ES", "GB", "FR", "NO", "BE",
#           "AT", "SE", "CH", "GR", "PT", "NL")
# df = data.frame(state = Region, code = code)
# data_pop = dplyr::left_join(data_pop, df, by = "state")
# data_pop$popt = NULL
# saveRDS(data_pop, file = "Europe/data/weighted_ifr_europe.RDS")
# 
# europe_regions = data.frame(
#   state_name = Region, code = code, pop_count = data_pop$popt,
#   pop_density = c(137, 206, 240, 94, 281, 119, 15, 383,
#                   109, 25, 219, 81, 111, 508),
#   region_census_sub_revised = c("N", "S", "E", "W", "W", "W", "N", "W",
#                                 "E", "N", "S", "E", "W", "N"),
#   region_code = c(1,2,3,4,4,4,1,4,3,1,2,3,4,1)
# )
# 
# write.csv(europe_regions, file = "Europe/data/europe-regions.csv", row.names = F)

#
#	file names used below
#	these are defined separately so they can be overwritten as needed for PID code
#

GFNAME_jhu_death_data_padded <<- "Europe/data/europe_death_data_padded.rds"
GFNAME_nyt_death_data_padded <<- "Europe/data/europe_death_data_padded.rds"
GFNAME_states <<- "Europe/data/states2.csv"
GFNAME_weighted_ifr <<- "Europe/data/weighted_ifr_europe.RDS"
GFNAME_global_mobility_report <<- 'Europe/data/Global_Mobility_Report.csv'
GFNAME_us_population <<- "Europe/data/europe_population.rds"
GFNAME_us_regions <<- "Europe/data/europe-regions.csv"

#
#	functions
#

smooth_fn = function(x, days=3) {
  return(rollmean(x, days, align = "right"))

}

read_death_data <- function(source, smooth = FALSE){
  if (source == "jhu"){
    death_data <- readRDS(GFNAME_jhu_death_data_padded)
  } else if (source ==  "nyt"){
    death_data <- readRDS(GFNAME_nyt_death_data_padded)
  }
  death_data <- death_data[which(death_data$date >= ymd("2020-02-1")),]
  
  if (smooth == TRUE){
    k = 3
    death_data$daily_deaths = c(rep(0, k-1), as.integer(smooth_fn(death_data$daily_deaths, days=k)))
  }
  
  #read regions
  regions <- read.csv('Europe/data/europe-regions.csv', stringsAsFactors = FALSE)
  death_data <- merge(death_data, regions, by = 'code')
  return(death_data)
}

read_ifr_data <- function(){
  state_ifr <- readRDS(GFNAME_weighted_ifr)
  return(state_ifr)
  
}

read_google_mobility <- function(){
  
  states <- read.csv(GFNAME_states, stringsAsFactors = FALSE)
  names(states) <- c("sub_region_1", "code")
  google_mobility <- read.csv(GFNAME_global_mobility_report, stringsAsFactors = FALSE)
  google_mobility$date = as.Date(google_mobility$date, format = '%Y-%m-%d')
  google_mobility <- google_mobility %>% 
                     filter(country_region_code %in% states$code)
  #Remove county level data
  google_mobility <- google_mobility[which(google_mobility$sub_region_2 == ""),]
  google_mobility <- left_join(google_mobility, states, by = c("sub_region_1"))
  
  
  names(google_mobility) <- c("country_region_code", "country_region", "sub_region_1", "sub_region_2", 
                              "metro_area",
                              "iso", "fips",
                              "date", "retail.recreation", "grocery.pharmacy", "parks", "transitstations",
                              "workplace", "residential", "code")
  google_mobility[, c("retail.recreation", "grocery.pharmacy", "parks", "transitstations", "workplace", "residential")] <- 
    google_mobility[, c("retail.recreation", "grocery.pharmacy", "parks", "transitstations", "workplace", "residential")]/100
  google_mobility[, c("retail.recreation", "grocery.pharmacy", "parks", "transitstations", "workplace")] <- 
    google_mobility[, c("retail.recreation", "grocery.pharmacy", "parks", "transitstations", "workplace")] * -1
  
  # Format the google mobility data
  google_mobility <- google_mobility %>% group_by(date, country_region_code) %>% 
    summarise_if(is.numeric, mean, na.rm = TRUE)
  
  google_mobility$sub_region_1 = ""
  google_mobility$sub_region_2 = ""
  google_mobility$metro_area = ""
  google_mobility$country_region = ""
  google_mobility$code = ""
  
  google_mobility <- select(google_mobility, "country_region_code", "country_region", "sub_region_1", 
                            "sub_region_2",
                            "date", "retail.recreation", "grocery.pharmacy", "parks", "transitstations",
                            "workplace", "residential", "code")
  google_mobility$code = google_mobility$country_region_code
  
  return(google_mobility)
}


read_pop_count_us = function(path_to_file = GFNAME_us_population){
  pop_count <- readRDS(path_to_file)
  pop_count <- pop_count[which(!is.na(pop_count$code)),] %>%
    reshape2::melt(id.vars = c("Region", "code")) %>%
    rename(age = variable, pop = value, state = Region)
  pop_count <- pop_count %>%
    group_by(state) %>%
    summarise(popt:= sum(pop)) 

  return(pop_count)
}

